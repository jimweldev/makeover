<?php

$baseUrl = "../";
$page = "transactions";

include $baseUrl . "assets/templates/client/header.inc.php";

?>

<?= alert(); ?>

<div id="carouselExampleIndicators" class="carousel carousel-dark slide d-print-none mb-4" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="../assets/img/photos/1.jpg" class="d-block w-100 h-100">
    </div>
    <div class="carousel-item">
      <img src="../assets/img/photos/2.jpg" class="d-block w-100 h-100">
    </div>
    <div class="carousel-item">
      <img src="../assets/img/photos/3.jpg" class="d-block w-100 h-100">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

<h1 class="h3 mb-3">Transactions</h1>

<div class="card">
	<div class="card-body">
		<table id="datatables-reponsive" class="table table-striped w-100">
			<thead>
				<tr>
					<th>Order ID</th>
					<th>Product Name</th>
					<th>Designer</th>
					<th>Total Payment</th>
					<th>Date</th>
					<th>Message</th>
				</tr>
			</thead>
			<tbody>

				<?php

				$clientsId = $_SESSION["id"];

				$sql = "SELECT * FROM orders WHERE clients_id = $clientsId";
				$result = mysqli_query($conn, $sql);

				while ($row = mysqli_fetch_assoc($result)) {

					echo "<tr>
						<td>" . (80000 + $row["id"]) . "</td>";

						$productsId = $row["products_id"];

						$sql2 = "SELECT * FROM products WHERE id = $productsId";
						$result2 = mysqli_query($conn, $sql2);

						while ($row2 = mysqli_fetch_assoc($result2)) {

							echo "<td>" . $row2["name"] . "</td>";

						}

						$designersId = $row["designers_id"];

						$sql2 = "SELECT * FROM users WHERE id = $designersId";
						$result2 = mysqli_query($conn, $sql2);

						while ($row2 = mysqli_fetch_assoc($result2)) {

							echo "<td>" . $row2["name"] . "</td>";

						}

						echo "<td>₱" . number_format($row["total_price"] - ($row["total_price"] / 100) * 5, 2) . "</td>
						<td>" . date('M d, Y', strtotime($row["created_at"])) . "</td>
						<td>
							<a class='btn btn-primary' href='./chat?id=" . $row["designers_id"] . "'>Send Message</a>
						</td>
					</tr>";

					}

				?>
				
			</tbody>
		</table>
	</div>
</div>

<?php

include $baseUrl . "assets/templates/client/footer.inc.php";

?>