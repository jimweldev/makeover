<?php

$baseUrl = "../";
$page = "transactions";

include $baseUrl . "assets/templates/client/header.inc.php";

?>

<h1 class="h3 mb-3">Chat</h1>

<?php

$clientsId = $_SESSION["id"];
$designersId = $_GET["id"];

$sql = "SELECT * FROM users WHERE id = $designersId";
$result = mysqli_query($conn, $sql);

echo "<div class='row'>";

	echo "<div class='col-8'>";

		if (mysqli_num_rows($result) > 0) {

			while ($row = mysqli_fetch_assoc($result)) {

				echo "<div class='card'>
					<div class='card-header'>
						<h5 class='card-title mb-0'>" . $row["name"] . "</h5>
					</div>

					<div class='card-body d-flex flex-column' id='chat-window' style='height: 40vh; overflow-y: auto; width: 100%'>";
						
						$sql2 = "SELECT * FROM messages WHERE designers_id = $designersId AND clients_id = $clientsId";
						$result2 = mysqli_query($conn, $sql2);

						if (mysqli_num_rows($result2) > 0) {

							while ($row2 = mysqli_fetch_assoc($result2)) {

								if ($row2["users_type"] == "client") {
								
									echo "<div class='ms-auto mb-4' >";
										echo "<p class='text-muted text-end mb-2'><small class='text-muted'>" . date('M d | h:i A', strtotime($row2["created_at"])) . "</small></p>";

										echo "<div class='bg-primary text-white rounded ms-auto p-2' style='max-width: 60%; width: max-content;'>";
											echo $row2["message"];
										echo "</div>";
									echo "</div>";

								} else {

									echo "<div class='mb-4'>";
										echo "<p class='text-muted mb-2'><small class='text-muted'>" . date('M d | h:i A', strtotime($row2["created_at"])) . "</small></p>";

										echo "<div class='bg-success text-white rounded p-2' style='max-width: 60%; width: max-content;'>";
											echo $row2["message"];
										echo "</div>";
									echo "</div>";

								}

							}

						} else {

							echo "No messages yet";

						}

					echo "</div>

					<form class='card-footer input-group mb-3' action='" . $baseUrl . "assets/includes/client/message.inc.php' method='POST'>
						<input type='hidden' name='clientsId' value='" . $clientsId . "'>
						<input type='hidden' name='designersId' value='" . $designersId . "'>
						<input class='form-control' type='text' name='message' autofocus>
						<button class='btn btn-primary input-group-text' name='sendMessage'>Send</button>
					</form>
				</div>";

			}

		}

	echo "</div>";

	echo "<div class='col-4'>";

		echo "<div class='card'>";

			echo "<div class='card-header'>";
				echo "<h5 class='card-title mb-0'>Images</h5>";
			echo "</div>";

			echo "<div class='card-body d-flex flex-column' style='height: 40vh; overflow-y: auto; width: 100%'>";

				$sql2 = "SELECT * FROM images WHERE designers_id = $designersId AND clients_id = $clientsId ORDER BY id DESC";
				$result2 = mysqli_query($conn, $sql2);

				if (mysqli_num_rows($result2) > 0) {

					while ($row2 = mysqli_fetch_assoc($result2)) {

						echo "<a class='mb-3' data-fancybox='gallery' data-src='" . $baseUrl . "assets/uploads/images/" . $row2["images"] . "'>
							<img class='w-100' src='" . $baseUrl . "assets/uploads/images/" . $row2["images"] . "' />
						</a>";

					}

				} else {
					echo "No images yet..";
				}

			echo "</div>";

			echo "<form class='card-footer input-group mb-3' action='" . $baseUrl . "assets/includes/client/media.inc.php' method='POST' enctype='multipart/form-data'>
				<input type='hidden' name='clientsId' value='" . $clientsId . "'>
				<input type='hidden' name='designersId' value='" . $designersId . "'>
				<input class='form-control' type='file' accept='image/*' name='image' />
				<button class='btn btn-primary input-group-text' name='sendImage'>Send</button>
			</form>";

		echo "</div>";

	echo "</div>";

echo "</div>";		

?>

<?php

include $baseUrl . "assets/templates/client/footer.inc.php";

?>

<script type="text/javascript">
	chatWindow = document.getElementById('chat-window'); 
	var xH = chatWindow.scrollHeight; 
	chatWindow.scrollTo(0, xH);
</script>