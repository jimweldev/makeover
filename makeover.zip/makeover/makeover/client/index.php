<?php

$baseUrl = "../";
$page = "home";

include $baseUrl . "assets/templates/client/header.inc.php";

?>

<?= alert(); ?>

<h1 class="h3 mb-3">Home</h1>

<div id="carouselExampleIndicators" class="carousel carousel-dark slide mb-4" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="../assets/img/photos/1.jpg" class="d-block w-100 h-100">
    </div>
    <div class="carousel-item">
      <img src="../assets/img/photos/2.jpg" class="d-block w-100 h-100">
    </div>
    <div class="carousel-item">
      <img src="../assets/img/photos/3.jpg" class="d-block w-100 h-100">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

<h1 class="display-4 text-center mb-4">Recent Products</h1>

<?php

echo "<div class='row'>";

	$sql = "SELECT * FROM products WHERE status = 'active' AND stocks <> 0 ORDER BY id DESC LIMIT 3";
	$result = mysqli_query($conn, $sql);

	if (mysqli_num_rows($result) > 0) {

		while ($row = mysqli_fetch_assoc($result)) {

			$usersId = $row["designers_id"];
			$productsId = $row["id"];

			$sql2 = "SELECT * FROM users WHERE id = $usersId";
			$result2 = mysqli_query($conn, $sql2);

			while ($row2 = mysqli_fetch_assoc($result2)) {

				$usersName = $row2["name"];

			}

			echo "<div class='col-lg-4'>
				<div class='card'>
					<div class='ratio ratio-16x9 rounded-top'>";
						
						$sql2 = "SELECT * FROM product_images WHERE products_id = $productsId LIMIT 1";
						$result2 = mysqli_query($conn, $sql2);

						while ($row2 = mysqli_fetch_assoc($result2)) {

							echo "<img class='rounded-top' src='" . $baseUrl . "assets/uploads/products/" . $row2["image"] . "'>";

						}
					
					echo "</div>

					<div class='card-body'>
						<h5 class='card-title mb-0'>" . $row["name"] . " <span class='badge bg-success'>" . $row["status"] . "</span></h5>
						<p class='card-text text-muted'>" . $usersName . " <span class='badge bg-primary'>" . $row["category"] . "</span></p>
						<p class='card-text'>" . $row["description"] . "</p>

						<table class='w-100 mb-3'>
							<tr>
								<th>Price</th>
								<th>Shipping Fee</th>
							</tr>
							<tr>
								<td>₱" . number_format($row["price"], 2) . "</td>
								<td>₱" . number_format($row["shipping_fee"], 2) . "</td>
							</tr>
							<tr>
								<th>Stocks</th>
								<th>Dimensions</th>
							</tr>
							<tr>
								<td>x" . $row["stocks"] . "</td>
								<td>" . $row["dimensions"] . "</td>
							</tr>
						</table>

						<a href='./view/product?id=" . $row["id"] . "' class='btn btn-primary'>View</a>
					</div>
				</div>
			</div>";

		}

	} else {

				echo "<div class='col-12'>";
					echo "<div class='card'>";
						echo "<div class='card-body'>";
							echo "<p class='lead mb-0'>No results..</p>";
						echo "</div>";
					echo "</div>";
				echo "</div>";

			}

			
echo "</div>";

?>

<?php

include $baseUrl . "assets/templates/client/footer.inc.php";

?>