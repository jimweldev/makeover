<?php

$baseUrl = "../";
$page = "designers";

include $baseUrl . "assets/templates/client/header.inc.php";

?>

<?= alert(); ?>

<div id="carouselExampleIndicators" class="carousel carousel-dark slide d-print-none mb-4" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="../assets/img/photos/1.jpg" class="d-block w-100 h-100">
    </div>
    <div class="carousel-item">
      <img src="../assets/img/photos/2.jpg" class="d-block w-100 h-100">
    </div>
    <div class="carousel-item">
      <img src="../assets/img/photos/3.jpg" class="d-block w-100 h-100">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

<h1 class="h3 mb-3">Designers</h1>

<form class="input-group mb-4" action="<?= $baseUrl ?>assets/includes/client/search.inc.php" method="POST">
	<input class="form-control form-control-lg" type="text" name="query" placeholder="Search items..">
	<button class="input-group-text btn-primary" type="submit" name="searchDesigners"><i class="align-middle" data-feather="search"></i></button>
</form>

<?php

$query = isset($_GET["q"]) ? $_GET["q"] : "";

$sql = "SELECT * FROM users WHERE role = 'designer' AND status = 'active' AND (name LIKE '%$query%' OR bio LIKE '%$query%') ORDER BY name ASC";
$result = mysqli_query($conn, $sql);

	if (mysqli_num_rows($result) > 0) {

		while ($row = mysqli_fetch_assoc($result)) {

			echo "<div class='card'>
				<div class='card-body'>
					<div class='row'>
						<div class='col-lg-4'>
							<img class='w-100' src='" . $baseUrl . "assets/uploads/cards/" . $row["card"] . "'>
						</div>
						<div class='col-lg-8'>
							<h1 class='h2'>" . $row["name"] . "</h1>
							<p class='card-text text-muted mb-0'>" . $row["email"] . "</p>
							<p class='card-text text-muted mb-0'>" . $row["address"] . "</p>
							<p class='card-text text-muted'>" . $row["contact_no"] . "</p>
							<p class='card-text'>" . $row["bio"] . "</p>
							<p class='card-text mb-0'><a href='" . $row["website"] . "'>Website</a></p>
							<p class='card-text mb-0'><a href='" . $row["facebook"] . "'>Facebook</a></p>
							
							<br>

							<a class='btn btn-primary' href='./chat?id=" . $row["id"] . "'>Send Message</a>
						</div>
					</div>
				</div>
			</div>";
		}

	}  else {

				echo "<div class='col-12'>";
					echo "<div class='card'>";
						echo "<div class='card-body'>";
							echo "<p class='lead mb-0'>No results..</p>";
						echo "</div>";
					echo "</div>";
				echo "</div>";

			}

?>

<?php

include $baseUrl . "assets/templates/client/footer.inc.php";

?>