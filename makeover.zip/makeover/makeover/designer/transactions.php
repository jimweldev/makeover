<?php

$baseUrl = "../";
$page = "transactions";

include $baseUrl . "assets/templates/designer/header.inc.php";

?>

<?= alert(); ?>

<h1 class="h3 mb-3">Transactions</h1>

<div class="card">
	<div class="card-header">
		<h5 class="card-title mb-0">Transactions</h5>
	</div>
	<div class="card-body">
		<table id="datatables-reponsive" class="table table-striped w-100">
			<thead>
				<tr>
					<th>Order ID</th>
					<th>Product Name</th>
					<th>Client</th>
					<th>Total Payment</th>
					<th>Date</th>
					<th>Message</th>
				</tr>
			</thead>
			<tbody>

				<?php

				$designersId = $_SESSION["id"];

				$sql = "SELECT * FROM orders WHERE designers_id = $designersId";
				$result = mysqli_query($conn, $sql);

				while ($row = mysqli_fetch_assoc($result)) {

					echo "<tr>
						<td>" . (80000 + $row["id"]) . "</td>";

						$productsId = $row["products_id"];

						$sql2 = "SELECT * FROM products WHERE id = $productsId";
						$result2 = mysqli_query($conn, $sql2);

						while ($row2 = mysqli_fetch_assoc($result2)) {

							echo "<td>" . $row2["name"] . "</td>";

						}

						$clientsId = $row["clients_id"];

						$sql2 = "SELECT * FROM users WHERE id = $clientsId";
						$result2 = mysqli_query($conn, $sql2);

						while ($row2 = mysqli_fetch_assoc($result2)) {

							echo "<td>" . $row2["name"] . "</td>";

						}

						echo "<td>₱" . number_format($row["total_price"] - ($row["total_price"] / 100) * 5, 2) . "</td>
						<td>" . date('M d', strtotime($row["created_at"])) . "</td>
						<td>
							<a class='btn btn-primary' href='./chat?id=" . $row["clients_id"] . "'>Send Message</a>
						</td>
					</tr>";

					}

				?>
				
			</tbody>
		</table>
	</div>
</div>

<?php

include $baseUrl . "assets/templates/designer/footer.inc.php";

?>