<?php

$baseUrl = "../../";
$page = "myProducts";

include $baseUrl . "assets/templates/designer/header.inc.php";

?>

<?= alert(); ?>

<div class="d-flex justify-content-between align-items-center mb-3">
	<h1 class="h3 mb-0">Add Product</h1>

	<a class="btn btn-primary" href="../my-products">Back</a>
</div>

<div class="row">
	<form class="col-lg-6 offset-lg-3" action="<?= $baseUrl; ?>assets/includes/designer/product.inc.php" method="POST" enctype="multipart/form-data">
		<div class="mb-3">
			<label class="form-label">Product Name</label>
			<input class="form-control form-control-lg" type="text" placeholder="Enter product name" name="name">
		</div>

		<div class='mb-3'>
			<label class='form-label'>Product Description</label>
			<textarea class='form-control' rows='5' placeholder='Enter product description' name='description' required></textarea>
		</div>

		<div class="mb-3">
			<label class="form-label">Category</label>
			<input class="form-control form-control-lg" type="text" placeholder="Enter product category" name="category">
		</div>

		<div class="mb-3">
			<label class="form-label">Images</label>
			<input class="form-control form-control-lg" type="file" multiple accept="image/*" name="images[]" />
		</div>

		<div class="mb-3">
			<label class="form-label">Price</label>
			<input class="form-control form-control-lg" type="number" step="0.25" placeholder="Enter product price" name="price">
		</div>

		<div class="mb-3">
			<label class="form-label">Shipping Fee</label>
			<input class="form-control form-control-lg" type="number" step="0.25" placeholder="Enter product shipping fee" name="shippingFee">
		</div>

		<div class="mb-3">
			<div class="row g-3">
				<div class="col-lg-6">
					<label class="form-label">Stocks</label>
					<input class="form-control form-control-lg" type="number" placeholder="Stocks" name="stocks">
				</div>
				<div class="col-lg-6">
					<label class="form-label">Dimensions</label>
					<input class="form-control form-control-lg" type="text" placeholder="Dimensions" name="dimensions">
				</div>
			</div>
		</div>

		<div class="text-center mt-3">
			<button class="btn btn-lg btn-primary" type="submit" name="addProduct">Submit</button>
		</div>
	</form>
</div>

<?php

include $baseUrl . "assets/templates/designer/footer.inc.php";

?>