<?php

$baseUrl = "../../";
$page = "profile";

include $baseUrl . "assets/templates/designer/header.inc.php";

?>

<?= alert(); ?>

<h1 class="h3 mb-3">Profile</h1>

<?php

$usersId = $_SESSION["id"];

$sql = "SELECT * FROM users WHERE id = $usersId";
$result = mysqli_query($conn, $sql);


while ($row = mysqli_fetch_assoc($result)) {

	echo "<div class='card'>";
		echo "<div class='card-body'>";
			echo "<div class='row'>";
				echo "<div class='col-lg-4'>";
					echo "<div class='list-group'>";
						echo "<a href='" . $baseUrl . "designer/profile' class='list-group-item list-group-item-action active'>
						Update Profile
						</a>";
						echo "<a href='" . $baseUrl . "designer/profile/change-password' class='list-group-item list-group-item-action'>Change Password</a>";
					echo "</div>";
				echo "</div>";

				echo "<div class='col-lg-8'>";
					echo "<h5 class='card-title mb-4'>Update Profile</h5>";

					echo "<div class='text-center mb-4'>";
						echo "<img alt='Charles Hall' src='" . $baseUrl . "assets/uploads/cards/" . $row["card"] . "' class='rounded img-responsive mt-2'
							height='128' />";
					echo "</div>";

					echo "<form action='" . $baseUrl . "assets/includes/designer/profile.inc.php' method='POST' enctype='multipart/form-data'>";
						echo "<div class='mb-3'>";
							echo "<label class='form-label'>Email</label>";
							echo "<input class='form-control form-control-lg' type='email' placeholder='Enter your bio' name='email' value='" . $row["email"] . "'>";
						echo "</div>";

						echo "<div class='mb-3'>";
							echo "<label class='form-label'>Name</label>";
							echo "<input class='form-control form-control-lg' type='text' placeholder='Enter your name' name='name' value='" . $row["name"] . "'>";
						echo "</div>";

						echo "<div class='mb-3'>";
							echo "<label class='form-label'>Bio</label>";
							echo "<input class='form-control form-control-lg' type='text' placeholder='Enter your bio' name='bio' value='" . $row["bio"] . "'>";
						echo "</div>";

						echo "<div class='mb-3'>";
							echo "<label class='form-label'>Website</label>";
							echo "<input class='form-control form-control-lg' type='text' placeholder='Enter your website' name='website' value='" . $row["website"] . "'>";
						echo "</div>";

						echo "<div class='mb-3'>";
							echo "<label class='form-label'>Facebook</label>";
							echo "<input class='form-control form-control-lg' type='text' placeholder='Enter your facebook' name='facebook' value='" . $row["facebook"] . "'>";
						echo "</div>";

						echo "<div class='mb-3'>";
							echo "<label class='form-label'>Address</label>";
							echo "<input class='form-control form-control-lg' type='text' placeholder='Enter your address' name='address' value='" . $row["address"] . "'>";
						echo "</div>";

						echo "<div class='mb-3'>";
							echo "<label class='form-label'>Contact No</label>";
							echo "<input class='form-control form-control-lg' type='text' placeholder='Enter your contact no' name='contactNo' value='" . $row["contact_no"] . "'>";
						echo "</div>";

						echo "<div class='mb-3'>";
							echo "<label class='form-label'>ID</label>";
							echo "<input class='form-control form-control-lg' type='file' accept='image/*' name='image' />";
						echo "</div>";

						echo "<div class='mb-3'>";
							echo "<label class='form-label'>Password</label>";
							echo "<input class='form-control form-control-lg' type='password' placeholder='Enter your password' name='password'>";
						echo "</div>";

						echo "<div class='text-center mt-3'>";
							echo "<button class='btn btn-lg btn-primary' type='submit' name='updateProfile'>Update</button>";
						echo "</div>";
					echo "</form>";
				echo "</div>";
			echo "</div>";
		echo "</div>";
	echo "</div>";

}

?>

<?php

include $baseUrl . "assets/templates/designer/footer.inc.php";

?>