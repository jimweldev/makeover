<?php

$baseUrl = "../../";
$page = "myProducts";

include $baseUrl . "assets/templates/designer/header.inc.php";

?>

<?= alert(); ?>

<div class="d-flex justify-content-between align-items-center mb-3">
	<h1 class="h3 mb-0">Edit Product</h1>

	<a class="btn btn-primary" href="../my-products">Back</a>
</div>

<?php

$productId = $_GET["id"];

$sql = "SELECT * FROM products WHERE id = $productId";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {

	while ($row = mysqli_fetch_assoc($result)) {

		echo "<div class='row'>
			<form class='col-lg-6 offset-lg-3' action='" . $baseUrl . "assets/includes/designer/product.inc.php' method='POST' enctype='multipart/form-data'>
				<input type='hidden' name='productsId' value='" . $row["id"] . "'>

				<div class='mb-3'>
					<label class='form-label'>Product Name</label>
					<input class='form-control form-control-lg' type='text' placeholder='Enter product name' name='name' value='" . $row["name"] . "'>
				</div>

				<div class='mb-3'>
					<label class='form-label'>Product Description</label>
					<textarea class='form-control' rows='5' placeholder='Enter product description' name='description' required>" . $row["description"] . "</textarea>
				</div>

				<div class='mb-3'>
					<label class='form-label'>Category</label>
					<input class='form-control form-control-lg' type='text' placeholder='Enter product category' name='category' value='" . $row["category"] . "'>
				</div>

				<div class='mb-3'>
					<label class='form-label'>Images</label>
					<input class='form-control form-control-lg' type='file' multiple accept='image/*' name='images[]' />
				</div>

				<div class='mb-3'>
					<label class='form-label'>Price</label>
					<input class='form-control form-control-lg' type='number' step='0.25' placeholder='Enter product price' name='price' value='" . $row["price"] . "'>
				</div>

				<div class='mb-3'>
					<label class='form-label'>Shipping Fee</label>
					<input class='form-control form-control-lg' type='number' step='0.25' placeholder='Enter product shipping fee' name='shippingFee' value='" . $row["shipping_fee"] . "'>
				</div>

				<div class='mb-3'>
					<div class='row g-3'>
						<div class='col-lg-6'>
							<label class='form-label'>Stocks</label>
							<input class='form-control form-control-lg' type='number' placeholder='Stocks' name='stocks' value='" . $row["stocks"] . "'>
						</div>
						<div class='col-lg-6'>
							<label class='form-label'>Dimensions</label>
							<input class='form-control form-control-lg' type='text' placeholder='Dimensions' name='dimensions' value='" . $row["dimensions"] . "'>
						</div>
					</div>
				</div>

				<div class='text-center mt-3'>
					<button class='btn btn-lg btn-primary' type='submit' name='editProduct'>Update</button>
				</div>
			</form>
		</div>";

	}

}

?>



<?php

include $baseUrl . "assets/templates/designer/footer.inc.php";

?>