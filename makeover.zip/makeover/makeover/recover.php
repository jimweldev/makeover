<?php

$baseUrl = "./";

include $baseUrl . "assets/templates/home/header.inc.php";

?>

<div class="py-5 px-4">
	<div class="container">

		<?= alert(); ?>
		
		<?php

		if (isset($_GET["email"])) {

			echo "<form class='row' action='" . $baseUrl . "assets/includes/sessions.inc.php' method='POST'>
				<div class='col-lg-4 offset-lg-4'>
					<h1 class='h3 text-center'>Recover</h1>

					<input type='hidden' name='email' value='" . $_GET["email"] . "'>

					<div class='mb-3'>
						<label class='form-label'>Code</label>
						<input class='form-control form-control-lg' type='text' placeholder='Enter your recovery code' name='code' required>
					</div>

					<div class='mb-3'>
						<label class='form-label'>New Password</label>
						<input class='form-control form-control-lg' type='password' placeholder='Enter your new password' name='password' pattern='(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}' title='Must contain at least one  number and one uppercase and lowercase letter, and at least 8 or more characters' required>
					</div>

					<div class='mb-3'>
						<label class='form-label'>Confirm Password</label>
						<input class='form-control form-control-lg' type='password' placeholder='Enter confirm password' name='confirmPassword' pattern='(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}' title='Must contain at least one  number and one uppercase and lowercase letter, and at least 8 or more characters' required>
					</div>

					<div class='text-center mt-3'>
						<button class='btn btn-lg btn-primary' type='submit' name='changePassword'>Recover</button>
					</div>
				</div>
			</form>";

		} else {

			echo "<form class='row' action='" . $baseUrl . "assets/includes/sessions.inc.php' method='POST'>
				<div class='col-lg-4 offset-lg-4'>
					<h1 class='h3 text-center'>Recover</h1>

					<div class='mb-3'>
						<label class='form-label'>Email</label>
						<input class='form-control form-control-lg' type='email' placeholder='Enter your email' name='email' required>
					</div>

					<div class='text-center mt-3'>
						<button class='btn btn-lg btn-primary' type='submit' name='recover'>Recover</button>
					</div>
				</div>
			</form>";

		}

		?>

	</div>
</div>

<?php

include $baseUrl . "assets/templates/home/footer.inc.php";

?>