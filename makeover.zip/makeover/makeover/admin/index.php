<?php

$baseUrl = "../";
$page = "dashboard";

include $baseUrl . "assets/templates/admin/header.inc.php";

?>

<?= alert(); ?>

<div id="carouselExampleIndicators" class="carousel carousel-dark slide d-print-none mb-4" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="../assets/img/photos/1.jpg" class="d-block w-100 h-100">
    </div>
    <div class="carousel-item">
      <img src="../assets/img/photos/2.jpg" class="d-block w-100 h-100">
    </div>
    <div class="carousel-item">
      <img src="../assets/img/photos/3.jpg" class="d-block w-100 h-100">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

<h1 class="display-4 text-center mb-4 d-none d-print-block">Sales Report</h1>

<div class="d-flex justify-content-between align-item-center mb-3">
	<h1 class="h3 mb-0">Dashboard</h1>

	<button class="btn btn-primary d-print-none" onclick="window.print()">Generate Report</button>
</div>

<div class="row">
	<div class="col-4">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col mt-0">
						<h5 class="card-title">Clients</h5>
					</div>

					<div class="col-auto">
						<div class="stat text-primary">
							<i class="align-middle" data-feather="users"></i>
						</div>
					</div>
				</div>
				<h1 class="mt-1 mb-0">

					<?php

					$sql = "SELECT * FROM users WHERE role = 'client' AND status = 'active'";
					$result = mysqli_query($conn, $sql);

					echo mysqli_num_rows($result);

					?>

				</h1>
			</div>
		</div>
	</div>

	<div class="col-4">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col mt-0">
						<h5 class="card-title">Designers</h5>
					</div>

					<div class="col-auto">
						<div class="stat text-primary">
							<i class="align-middle" data-feather="user"></i>
						</div>
					</div>
				</div>
				<h1 class="mt-1 mb-0">

					<?php

					$sql = "SELECT * FROM users WHERE role = 'designer' AND status = 'active'";
					$result = mysqli_query($conn, $sql);

					echo mysqli_num_rows($result);

					?>

				</h1>
			</div>
		</div>
	</div>

	<div class="col-4">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col mt-0">
						<h5 class="card-title">Products</h5>
					</div>

					<div class="col-auto">
						<div class="stat text-primary">
							<i class="align-middle" data-feather="shopping-bag"></i>
						</div>
					</div>
				</div>
				<h1 class="mt-1 mb-0">

					<?php

					$sql = "SELECT * FROM products WHERE status = 'active'";
					$result = mysqli_query($conn, $sql);

					echo mysqli_num_rows($result);

					?>

				</h1>
			</div>
		</div>
	</div>

	<div class="col-3">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col mt-0">
						<h5 class="card-title">Earnings (daily)</h5>
					</div>

					<div class="col-auto">
						<div class="stat text-primary">
							<i class="align-middle" data-feather="stop-circle"></i>
						</div>
					</div>
				</div>
				<h1 class="mt-1 mb-0">
					
					<?php

					$date = date('Y-m-d');

					$sql = "SELECT SUM(total_price) as total_price FROM orders WHERE created_at = '$date'";
					$result = mysqli_query($conn, $sql);

					if (mysqli_num_rows($result) > 0) {

						while ($row = mysqli_fetch_assoc($result)) {

							echo "₱" . number_format(($row["total_price"] / 100) * 5, 2);

						}

					}

					?>

				</h1>
			</div>
		</div>
	</div>

	<div class="col-3">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col mt-0">
						<h5 class="card-title">Earnings (monthly)</h5>
					</div>

					<div class="col-auto">
						<div class="stat text-primary">
							<i class="align-middle" data-feather="stop-circle"></i>
						</div>
					</div>
				</div>
				<h1 class="mt-1 mb-0">

					<?php

					$date = date("Y-m-d");
					$first = date("Y-m-01");
					$last = date("Y-m-t");

					$sql = "SELECT SUM(total_price) as total_price FROM orders WHERE created_at BETWEEN '$first' AND '$last'";
					$result = mysqli_query($conn, $sql);

					if (mysqli_num_rows($result) > 0) {

						while ($row = mysqli_fetch_assoc($result)) {

							echo "₱" . number_format(($row["total_price"] / 100) * 5, 2);

						}

					}

					?>

				</h1>
			</div>
		</div>
	</div>

	<div class="col-3">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col mt-0">
						<h5 class="card-title">Earnings (annually)</h5>
					</div>

					<div class="col-auto">
						<div class="stat text-primary">
							<i class="align-middle" data-feather="stop-circle"></i>
						</div>
					</div>
				</div>
				<h1 class="mt-1 mb-0">

					<?php

					$date = date("Y-m-d");
					$first = date("Y-01-01");
					$last = date("Y-12-t");

					$sql = "SELECT SUM(total_price) as total_price FROM orders WHERE created_at BETWEEN '$first' AND '$last'";
					$result = mysqli_query($conn, $sql);

					if (mysqli_num_rows($result) > 0) {

						while ($row = mysqli_fetch_assoc($result)) {

							echo "₱" . number_format(($row["total_price"] / 100) * 5, 2);

						}

					}

					?>

				</h1>
			</div>
		</div>
	</div>

	<div class="col-3">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col mt-0">
						<h5 class="card-title">Earnings (total)</h5>
					</div>

					<div class="col-auto">
						<div class="stat text-primary">
							<i class="align-middle" data-feather="stop-circle"></i>
						</div>
					</div>
				</div>
				<h1 class="mt-1 mb-0">

					<?php

					$sql = "SELECT SUM(total_price) as total_price FROM orders";
					$result = mysqli_query($conn, $sql);

					if (mysqli_num_rows($result) > 0) {

						while ($row = mysqli_fetch_assoc($result)) {

							echo "₱" . number_format(($row["total_price"] / 100) * 5, 2);

						}

					}

					?>

				</h1>
			</div>
		</div>
	</div>
</div>

<div class="card">
	<div class="card-header">
		<h5 class="card-title mb-0">Transactions</h5>
	</div>
	<div class="card-body">
		<table id="datatables-reponsive" class="table table-striped w-100">
			<thead>
				<tr>
					<th>Order ID</th>
					<th>Product Name</th>
					<th>Designer</th>
					<th>Client</th>
					<th>Commission</th>
					<th>Date</th>
				</tr>
			</thead>
			<tbody>

				<?php

				$sql = "SELECT * FROM orders";
				$result = mysqli_query($conn, $sql);

				while ($row = mysqli_fetch_assoc($result)) {

					echo "<tr>
						<td>" . (80000 + $row["id"]) . "</td>";

						$productsId = $row["products_id"];

						$sql2 = "SELECT * FROM products WHERE id = $productsId";
						$result2 = mysqli_query($conn, $sql2);

						while ($row2 = mysqli_fetch_assoc($result2)) {

							echo "<td>" . $row2["name"] . "</td>";

						}

						$designersId = $row["designers_id"];

						$sql2 = "SELECT * FROM users WHERE id = $designersId";
						$result2 = mysqli_query($conn, $sql2);

						while ($row2 = mysqli_fetch_assoc($result2)) {

							echo "<td>" . $row2["name"] . "</td>";

						}

						$clientsId = $row["clients_id"];

						$sql2 = "SELECT * FROM users WHERE id = $clientsId";
						$result2 = mysqli_query($conn, $sql2);

						while ($row2 = mysqli_fetch_assoc($result2)) {

							echo "<td>" . $row2["name"] . "</td>";

						}

						echo "<td>₱" . number_format($row["total_price"] - ($row["total_price"] / 100) * 5, 2) . "</td>
						<td>" . date('M d, Y', strtotime($row["created_at"])) . "</td>
					</tr>";

					}

				?>
				
			</tbody>
		</table>
	</div>
</div>

<?php

include $baseUrl . "assets/templates/admin/footer.inc.php";

?>