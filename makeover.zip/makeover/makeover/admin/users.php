<?php

$baseUrl = "../";
$page = "users";

include $baseUrl . "assets/templates/admin/header.inc.php";

?>

<?= alert(); ?>

<div id="carouselExampleIndicators" class="carousel carousel-dark slide d-print-none mb-4" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="../assets/img/photos/1.jpg" class="d-block w-100 h-100">
    </div>
    <div class="carousel-item">
      <img src="../assets/img/photos/2.jpg" class="d-block w-100 h-100">
    </div>
    <div class="carousel-item">
      <img src="../assets/img/photos/3.jpg" class="d-block w-100 h-100">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

<h1 class="h3 mb-3">Users</h1>

<div class="card">
	<div class="card-body">
		<table id="datatables-reponsive" class="table table-striped w-100">
			<thead>
				<tr>
					<th>ID</th>
					<th>Users</th>
					<th>Role</th>
					<th width="20%">ID Card</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				
				<?php

				$sql = "SELECT * FROM users WHERE role <> 'admin'";
				$result = mysqli_query($conn, $sql);

					if (mysqli_num_rows($result) > 0) {

						while ($row = mysqli_fetch_assoc($result)) {

							echo "<tr>
								<td>" . (80000 + $row["id"]) . "</td>
								<td>" . $row["name"] . "</td>
								<td>" . $row["role"] . "</td>
								<td>
									<a data-fancybox='" . $row["id"] . "' data-src='" . $baseUrl . "assets/uploads/cards/" . $row["card"] . "'>
										<img class='w-100' src='" . $baseUrl . "assets/uploads/cards/" . $row["card"] . "' />
									</a>
								</td>";

								if ($row["status"] == "inactive") {

									echo "<td><a class='btn btn-success' data-bs-toggle='modal' data-bs-target='#activateModal' data-bs-name='" . $row["name"] . "' data-bs-href='" . $baseUrl . "assets/includes/admin/user.inc.php?activateUser&id=" . $row["id"] . "'>Activate</a></td>";

								} else {

									echo "<td><a class='btn btn-danger' data-bs-toggle='modal' data-bs-target='#deactivateModal' data-bs-name='" . $row["name"] . "' data-bs-href='" . $baseUrl . "assets/includes/admin/user.inc.php?deactivateUser&id=" . $row["id"] . "'>Deactivate</a></td>";

								}

								
							echo "</tr>";

						}

					}

				?>

			</tbody>
		</table>
	</div>
</div>

<?php

include $baseUrl . "assets/templates/admin/footer.inc.php";

?>

<!-- ACTIVATE -->
<div class="modal fade" id="activateModal" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Activate User</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<p>Are you sure you want to activate <strong class="data"></strong>?</p>
			</div>
			<div class="modal-footer">
				<a href="#" class="btn btn-secondary" data-bs-dismiss="modal">Close</a>
				<a href="#" class="btn btn-success data">Activate</a>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	var activateModal = document.getElementById('activateModal')

	activateModal.addEventListener('show.bs.modal', function (event) {
		var button = event.relatedTarget

		var name = button.getAttribute('data-bs-name')
		var modalBodyName = activateModal.querySelector('.modal-body .data')
		modalBodyName.innerHTML = name

		var href = button.getAttribute('data-bs-href')
		var modalFooterHref = activateModal.querySelector('.modal-footer .data')
		modalFooterHref.href = href;
	})
</script>

<!-- DEACTIVATE -->
<div class="modal fade" id="deactivateModal" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Deactivate User</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<p>Are you sure you want to deactivate <strong class="data"></strong>?</p>
			</div>
			<div class="modal-footer">
				<a href="#" class="btn btn-secondary" data-bs-dismiss="modal">Close</a>
				<a href="#" class="btn btn-danger data">Deactivate</a>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	var deactivateModal = document.getElementById('deactivateModal')

	deactivateModal.addEventListener('show.bs.modal', function (event) {
		var button = event.relatedTarget

		var name = button.getAttribute('data-bs-name')
		var modalBodyName = deactivateModal.querySelector('.modal-body .data')
		modalBodyName.innerHTML = name

		var href = button.getAttribute('data-bs-href')
		var modalFooterHref = deactivateModal.querySelector('.modal-footer .data')
		modalFooterHref.href = href;
	})
</script>