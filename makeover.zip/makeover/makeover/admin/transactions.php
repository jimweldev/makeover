<?php

$baseUrl = "../";
$page = "transactions";

include $baseUrl . "assets/templates/admin/header.inc.php";

?>

<?= alert(); ?>

<h1 class="h3 mb-3">Transactions</h1>

<div class="card">
	<div class="card-body">
		<table id="datatables-reponsive" class="table table-striped w-100">
			<thead>
				<tr>
					<th>ID</th>
					<th>Seller</th>
					<th>Product</th>
					<th>Price</th>
					<th>Commission</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>1</td>
					<td>Seller</td>
					<td>Product</td>
					<td>Price</td>
					<td>Commission</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>

<?php

include $baseUrl . "assets/templates/admin/footer.inc.php";

?>