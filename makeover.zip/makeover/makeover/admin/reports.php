<?php

$baseUrl = "../";
$page = "reports";

include $baseUrl . "assets/templates/admin/header.inc.php";

echo "<input type='hidden' id='sellerId' value='" . $_SESSION["id"] . "'>";

?>

<div class="mb-3 d-flex justify-content-between align-items-center d-print-none">
	<h1 class="h3 mb-0">Reports</h1>

	<a class="btn btn-primary" onclick="window.print();">Generate Report</a>
</div>

<div class="d-flex justify-content-between align-items-center mb-4 d-none d-print-flex">
	<img src="../assets/img/icons/logo.png" width="50px">

	<h2 class="mb-0">Sales Roport</h2>

	<p class="mb-0"><?= date("m/d/Y"); ?></p>
</div>

<div class="d-print-none">
	<div class="row">
		<div class="col-lg-6 mb-3">
			<label class="form-label">Month</label>
			<select class="form-select form-select-lg" id="selectMonth">
				<option selected value="1">January</option>
				<option value="2">February</option>
				<option value="3">March</option>
				<option value="4">April</option>
				<option value="5">May</option>
				<option value="6">June</option>
				<option value="7">July</option>
				<option value="8">August</option>
				<option value="9">Sepember</option>
				<option value="10">October</option>
				<option value="11">November</option>
				<option value="12">December</option>
			</select>
		</div>
		<div class="col-lg-6 mb-3">
			<label class="form-label">Year</label>
			<select class="form-select form-select-lg" id="selectYear">
				<option selected value="2022">2022</option>
				<option value="2021">2021</option>
				<option value="2020">2020</option>
			</select>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-4">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col mt-0">
						<h5 class="card-title">Date</h5>
					</div>

					<div class="col-auto">
						<div class="stat text-primary">
							<i class="align-middle" data-feather="calendar"></i>
						</div>
					</div>
				</div>
				<h1 class="mt-1 mb-0" id="months">
					January 2022
				</h1>
			</div>
		</div>
	</div>

	<div class="col-4">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col mt-0">
						<h5 class="card-title">Sales</h5>
					</div>

					<div class="col-auto">
						<div class="stat text-primary">
							<i class="align-middle" data-feather="truck"></i>
						</div>
					</div>
				</div>
				<h1 class="mt-1 mb-0" id="sales">

				</h1>
			</div>
		</div>
	</div>

	<div class="col-4">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col mt-0">
						<h5 class="card-title">Earnings</h5>
					</div>

					<div class="col-auto">
						<div class="stat text-primary">
							<i class="align-middle" data-feather="disc"></i>
						</div>
					</div>
				</div>
				<h1 class="mt-1 mb-0" id="earnings">
					
				</h1>
			</div>
		</div>
	</div>
</div>

<div class="card">
	<div class="card-header">
		<h5 class="card-title">Sales</h5>
	</div>
	<div class="card-body">
		<div class="table-responsive">
			<table class="table table-striped w-100">
				<thead>
					<tr>
						<th>Order ID</th>
						<th>Product Name</th>
						<th>Designer</th>
						<th>Client</th>
						<th>Commission</th>
						<th>Date</th>
					</tr>
				</thead>
				<tbody id="data">

				</tbody>
			</table>
		</div>
			
	</div>
</div>

<?php

include $baseUrl . "assets/templates/admin/footer.inc.php";

?>

	
<script>
	function getReport(seller, month, year) {

		var xmlhttp = new XMLHttpRequest();
		
		xmlhttp.onreadystatechange = function() {

			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("data").innerHTML = this.responseText;
			}
		}

		xmlhttp.open("GET", "../assets/includes/admin/reports.inc.php?table&seller=" + seller + "&month=" + month + "&year=" + year, true);
		xmlhttp.send();

	}

	function getSales(seller, month, year) {

		var xmlhttp = new XMLHttpRequest();
		
		xmlhttp.onreadystatechange = function() {

			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("sales").innerHTML = this.responseText;
			}
		}

		xmlhttp.open("GET", "../assets/includes/admin/reports.inc.php?sales&seller=" + seller + "&month=" + month + "&year=" + year, true);
		xmlhttp.send();

	}

	function getEarnings(seller, month, year) {

		var xmlhttp = new XMLHttpRequest();
		
		xmlhttp.onreadystatechange = function() {

			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("earnings").innerHTML = this.responseText;
			}
		}

		xmlhttp.open("GET", "../assets/includes/admin/reports.inc.php?earnings&seller=" + seller + "&month=" + month + "&year=" + year, true);
		xmlhttp.send();

	}

	let seller = document.getElementById("sellerId").value;
	let month = document.getElementById("selectMonth").value;
	let year = document.getElementById("selectYear").value;

	getReport(seller, month, year);
	getSales(seller, month, year);
	getEarnings(seller, month, year);

	document.getElementById("selectMonth").onchange = () => {
		let seller = document.getElementById("sellerId").value;
		let month = document.getElementById("selectMonth").value;
		let year = document.getElementById("selectYear").value;

		if (month == 1) {
			document.getElementById("months").innerHTML = "January " + year;
		} else if (month == 2) {
			document.getElementById("months").innerHTML = "February " + year;
		} else if (month == 3) {
			document.getElementById("months").innerHTML = "March " + year;
		} else if (month == 4) {
			document.getElementById("months").innerHTML = "April " + year;
		} else if (month == 5) {
			document.getElementById("months").innerHTML = "May " + year;
		} else if (month == 6) {
			document.getElementById("months").innerHTML = "June " + year;
		} else if (month == 7) {
			document.getElementById("months").innerHTML = "July " + year;
		} else if (month == 8) {
			document.getElementById("months").innerHTML = "August " + year;
		} else if (month == 9) {
			document.getElementById("months").innerHTML = "September " + year;
		} else if (month == 10) {
			document.getElementById("months").innerHTML = "October " + year;
		} else if (month == 11) {
			document.getElementById("months").innerHTML = "November " + year;
		} else if (month == 12) {
			document.getElementById("months").innerHTML = "December " + year;
		}

		getReport(seller, month, year);
		getSales(seller, month, year);
		getEarnings(seller, month, year);
	}

	document.getElementById("selectYear").onchange = () => {
		let seller = document.getElementById("sellerId").value;
		let month = document.getElementById("selectMonth").value;
		let year = document.getElementById("selectYear").value;

		if (month == 1) {
			document.getElementById("months").innerHTML = "January " + year;
		} else if (month == 2) {
			document.getElementById("months").innerHTML = "February " + year;
		} else if (month == 3) {
			document.getElementById("months").innerHTML = "March " + year;
		} else if (month == 4) {
			document.getElementById("months").innerHTML = "April " + year;
		} else if (month == 5) {
			document.getElementById("months").innerHTML = "May " + year;
		} else if (month == 6) {
			document.getElementById("months").innerHTML = "June " + year;
		} else if (month == 7) {
			document.getElementById("months").innerHTML = "July " + year;
		} else if (month == 8) {
			document.getElementById("months").innerHTML = "August " + year;
		} else if (month == 9) {
			document.getElementById("months").innerHTML = "September " + year;
		} else if (month == 10) {
			document.getElementById("months").innerHTML = "October " + year;
		} else if (month == 11) {
			document.getElementById("months").innerHTML = "November " + year;
		} else if (month == 12) {
			document.getElementById("months").innerHTML = "December " + year;
		}

		getReport(seller, month, year);
		getSales(seller, month, year);
		getEarnings(seller, month, year);
	}
</script>