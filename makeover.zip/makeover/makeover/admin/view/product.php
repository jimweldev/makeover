<?php

$baseUrl = "../../";
$page = "products";

include $baseUrl . "assets/templates/admin/header.inc.php";

?>

<div class="d-flex justify-content-between align-items-center mb-3">
	<h1 class="h3 mb-0">View Product</h1>

	<a class="btn btn-primary" href="../products">Back</a>
</div>

<?php

$productsId = $_GET["id"];

$sql = "SELECT * FROM products WHERE id = $productsId";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {

	while ($row = mysqli_fetch_assoc($result)) {

		$usersId = $row["designers_id"];

		$sql2 = "SELECT * FROM users WHERE id = $usersId";
		$result2 = mysqli_query($conn, $sql2);

		while ($row2 = mysqli_fetch_assoc($result2)) {

			$usersName = $row2["name"];

		}

		echo "<div class='card'>
			<div class='card-body'>
				<div class='row g-3'>
					<div class='col-lg-4'>
						<h5 class='card-title mb-0'>" . $row["name"] . "</h5>
						<p class='card-text text-muted'>" . $usersName . " <span class='badge bg-primary'>" . $row["category"] . "</span></p>
						<p class='card-text'>" . $row["description"] . "</p>

						<table class='w-100 mb-3'>
							<tr>
								<th>Price</th>
								<th>Shipping Fee</th>
							</tr>
							<tr>
								<td>₱" . number_format($row["price"], 2) . "</td>
								<td>₱" . number_format($row["shipping_fee"], 2) . "</td>
							</tr>
							<tr>
								<th>Stocks</th>
								<th>Dimensions</th>
							</tr>
							<tr>
								<td>x" . $row["stocks"] . "</td>
								<td>" . $row["dimensions"] . "</td>
							</tr>
						</table>
					</div>

					<div class='col-lg-8'>";
						echo "<div class='row g-3'>";
						
							$sql2 = "SELECT * FROM product_images WHERE products_id = $productsId";
							$result2 = mysqli_query($conn, $sql2);

							while ($row2 = mysqli_fetch_assoc($result2)) {

								echo "<div class='col-lg-6 flex-fill'>";
									echo "<a data-fancybox='gallery' data-src='" . $baseUrl . "/assets/uploads/products/" . $row2["image"] . "'>";
										echo "<div class='ratio ratio-16x9'>";
											echo "<img class='rounded w-100' src='" . $baseUrl . "/assets/uploads/products/" . $row2["image"] . "'>";
										echo "</div>";
									echo "</a>";
								echo "</div>";

							}

						echo "</div>
					</div>
				</div>
			</div>
		</div>";

	}

}

		

?>

<?php

include $baseUrl . "assets/templates/admin/footer.inc.php";

?>

<div class="modal fade" id="payModal" tabindex="-1" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">PayPal</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<p>Are you sure you want to buy <strong class="data"></strong>?</p>

				<div class="mb-3">
					<label class="form-label">Email</label>
					<input class="form-control form-control-lg" type="email" placeholder="Enter email">
				</div>

				<div class="mb-3">
					<label class="form-label">Password</label>
					<input class="form-control form-control-lg" type="password" placeholder="Enter password">
				</div>
			</div>
			<div class="modal-footer">
				<a href="#" class="btn btn-secondary" data-bs-dismiss="modal">Close</a>
				<a href="#" class="btn btn-primary data">Pay Now</a>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
	var payModal = document.getElementById('payModal')

	payModal.addEventListener('show.bs.modal', function (event) {
		var button = event.relatedTarget

		var name = button.getAttribute('data-bs-name')
		var modalBodyName = payModal.querySelector('.modal-body .data')
		modalBodyName.innerHTML = name

		var href = button.getAttribute('data-bs-href')
		var modalFooterHref = payModal.querySelector('.modal-footer .data')
		modalFooterHref.href = href;
	})
</script>