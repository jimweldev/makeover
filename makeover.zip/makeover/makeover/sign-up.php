<?php

$baseUrl = "./";

include $baseUrl . "assets/templates/home/header.inc.php";

?>

<div class="py-5 px-4">
	<div class="container">

		<?= alert(); ?>
		
		<div class="row">
			<form class="col-lg-6 offset-lg-3" action="<?= $baseUrl; ?>assets/includes/sessions.inc.php" method="POST" enctype="multipart/form-data">
				<h1 class="h3 text-center">Sign up</h1>

				<div class="mb-3">
					<label class="form-label">Name</label>
					<div class="row g-3">
						<div class="col-lg-6">
							<input class="form-control form-control-lg" type="text" placeholder="First name" name="firstname" value="<?= value("firstname"); ?>" pattern="[a-zA-Z\s]+" title="Numbers and Symbols are not allowed" required>
						</div>
						<div class="col-lg-6">
							<input class="form-control form-control-lg" type="text" placeholder="Last name" name="lastname" value="<?= value("lastname"); ?>" pattern="[a-zA-Z\s]+" title="Numbers and Symbols are not allowed" required>
						</div>
					</div>
				</div>

				<div class="mb-3">
					<label class="form-label">Complete Address</label>
					<input class="form-control form-control-lg" type="text" placeholder="Enter your complete address" name="address" value="<?= value("lastname"); ?>" required>
				</div>

				<div class="mb-3">
					<label class="form-label">Contact No</label>
					<input class="form-control form-control-lg" type="text" placeholder="Enter your contact no" name="contactNo" value="<?= value("contactNo"); ?>" pattern="09+[0-9]{9}" title="Enter a valid contact number" required>
				</div>

				<div class="mb-3">
					<label class="form-label">ID</label>
					<input class="form-control form-control-lg" type="file" accept="image/*" name="image" required />
				</div>

				<div class="mb-3">
					<label class="form-label">Role</label>
					<select class="form-select form-select-lg" name="role" required>
						<option selected value="client">Client</option>
						<option value="designer">Designer</option>
					</select>
				</div>

				<div class="mb-3">
					<label class="form-label">Email</label>
					<input class="form-control form-control-lg" type="email" placeholder="Enter your email" name="email" value="<?= value("email"); ?>" required>
				</div>

				<div class="mb-3">
					<label class="form-label">Password</label>
					<div class="row g-3">
						<div class="col-lg-6">
							<input class="form-control form-control-lg" type="password" placeholder="Password" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one  number and one uppercase and lowercase letter, and at least 8 or more characters" required>
						</div>
						<div class="col-lg-6">
							<input class="form-control form-control-lg" type="password" placeholder="Confirm Password" name="confirmPassword" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one  number and one uppercase and lowercase letter, and at least 8 or more characters" required>
						</div>
					</div>
				</div>

				<div class="form-check">
					<input class="form-check-input" type="checkbox" value="" id="flexCheckDefault" name="termsAndConditions">
					<label class="form-check-label" for="flexCheckDefault">
						I agree with all <a href="">Terms & Conditions</a>
					</label>
				</div>

				<div class="text-center mt-3">
					<button class="btn btn-lg btn-primary" type="submit" name="signUp">Sign up</button>
				</div>
			</form>
		</div>

	</div>
</div>

<?php

include $baseUrl . "assets/templates/home/footer.inc.php";

?>