<?php

include $baseUrl . "assets/includes/dbh.inc.php";

session_start();

allowedRole($baseUrl, "designer");

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">
	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="shortcut icon" href="<?= $baseUrl; ?>assets/img/icons/logo.png" />
	<link rel="canonical" href="https://demo-basic.adminkit.io/pages-blank.html" />
	<title>Room Makeover</title>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.4/css/dataTables.bootstrap5.min.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0/dist/fancybox.css"/>
	<link href="<?= $baseUrl; ?>assets/css/app.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>
<div class="wrapper">
	<nav id="sidebar" class="sidebar js-sidebar">
		<div class="sidebar-content js-simplebar">
			<a class="sidebar-brand" href="<?= $baseUrl; ?>client">
				<span class="align-middle">Room Makeover</span>
			</a>

			<ul class="sidebar-nav">
				<li class="sidebar-item <?= page("dashboard", $page); ?>">
					<a class="sidebar-link" href="<?= $baseUrl; ?>designer">
						<i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
					</a>
				</li>

				<li class="sidebar-item <?= page("reports", $page); ?>">
					<a class="sidebar-link" href="<?= $baseUrl; ?>designer/reports">
						<i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Reports</span>
					</a>
				</li>

				<li class="sidebar-item <?= page("myProducts", $page); ?>">
					<a class="sidebar-link" href="<?= $baseUrl; ?>designer/my-products">
						<i class="align-middle" data-feather="shopping-bag"></i> <span class="align-middle">My Products</span>
					</a>
				</li>
			</ul>
		</div>
	</nav>

	<div class="main">
		<nav class="navbar navbar-expand navbar-light navbar-bg d-print-none">
			<a class="sidebar-toggle js-sidebar-toggle">
				<i class="hamburger align-self-center"></i>
			</a>

			<div class="navbar-collapse collapse">
				<ul class="navbar-nav navbar-align">
					<li class="nav-item dropdown">
						<a class="nav-icon dropdown-toggle" href="#" id="alertsDropdown" data-bs-toggle="dropdown">
							<div class="position-relative">
								<i class="align-middle" data-feather="bell"></i>
								
								<?php

								$designersId = $_SESSION["id"];

								$sql = "SELECT * FROM notifications WHERE users_id = $designersId AND status = 'unseen'";
								$result = mysqli_query($conn, $sql);

								if (mysqli_num_rows($result) > 0) {

									echo "<span class='indicator'>" . mysqli_num_rows($result) . "</span>";

								}

								?>

							</div>
						</a>
						<div class="dropdown-menu dropdown-menu-lg dropdown-menu-end py-0" aria-labelledby="alertsDropdown">
							<div class="dropdown-menu-header">
								Notifications
							</div>
							<div class="list-group">

								<?php

								$usersId = $_SESSION["id"];

								$sql = "SELECT * FROM notifications WHERE users_id = $usersId ORDER BY id DESC";
								$result = mysqli_query($conn, $sql);

								if (mysqli_num_rows($result) > 0) {

									while ($row = mysqli_fetch_assoc($result)) {

										echo "<a href='" . $baseUrl . "assets/includes/designer/notification.inc.php?viewNotification&id=" . $row["id"] . "' class='list-group-item'>
											<div class='row g-0 align-items-center'>
												<div class='col-2'>
													<i class='text-info' data-feather='alert-circle'></i>
												</div>
												<div class='col-10'>";

													if ($row["status"] == "unseen") {
														
														echo "<div class='text-dark fw-bold'>" . $row["title"] . "</div>
														<div class='text-muted fw-bold small mt-1'>" . $row["description"] . "</div>
														<div class='text-muted fw-bold small mt-1'>" . date('M d | h:i A', strtotime($row["created_at"])) . "</div>";

													} else {

														echo "<div class='text-dark'>" . $row["title"] . "</div>
														<div class='text-muted small mt-1'>" . $row["description"] . "</div>
														<div class='text-muted small mt-1'>" . date('M d | h:i A', strtotime($row["created_at"])) . "</div>";

													}

														
												echo "</div>
											</div>
										</a>";

									}

								}

								?>

								
							</div>
							<div class="dropdown-menu-footer">
								<a href="#" class="text-muted">Show all notifications</a>
							</div>
						</div>
					</li>
					<li class="nav-item dropdown">
						<a class="nav-icon dropdown-toggle" href="#" id="messagesDropdown" data-bs-toggle="dropdown">
							<div class="position-relative">
								<i class="align-middle" data-feather="message-square"></i>

								<?php

								$designersId = $_SESSION["id"];

								$sql = "SELECT a.* FROM messages a INNER JOIN (SELECT id, users_type, message, created_at, MAX(id) AS maxid FROM messages WHERE designers_id = $designersId AND users_type = 'client' AND status = 'unseen' GROUP BY clients_id) as b ON a.id = b.maxid ORDER BY a.id DESC";
								$result = mysqli_query($conn, $sql);

								if (mysqli_num_rows($result) > 0) {

									echo "<span class='indicator'>" . mysqli_num_rows($result) . "</span>";

								}

								?>

							</div>
						</a>
						<div class="dropdown-menu dropdown-menu-lg dropdown-menu-end py-0" aria-labelledby="messagesDropdown">
							<div class="dropdown-menu-header">
								<div class="position-relative">
									Messages
								</div>
							</div>
							<div class="list-group">

								<?php

								$designersId = $_SESSION["id"];

								$sql = "SELECT a.* FROM messages a INNER JOIN (SELECT id, users_type, message, created_at, MAX(id) AS maxid FROM messages WHERE designers_id = $designersId GROUP BY clients_id) as b ON a.id = b.maxid ORDER BY a.id DESC LIMIT 4";
								$result = mysqli_query($conn, $sql);

								if (mysqli_num_rows($result) > 0) {

									while ($row = mysqli_fetch_assoc($result)) {

										echo "<a href='" . $baseUrl . "assets/includes/designer/message.inc.php?viewMessage&id=" . $row["clients_id"] . "' class='list-group-item'>
											<div class='row g-0 align-items-center'>
												<div class='col-2'>";
													
													$clientsId = $row["clients_id"];

													$sql2 = "SELECT * FROM users WHERE id = $clientsId";
													$result2 = mysqli_query($conn, $sql2);

													while ($row2 = mysqli_fetch_assoc($result2)) {

														echo "<img src='" . $baseUrl . "assets/uploads/cards/" . $row2["card"] . "' class='avatar img-fluid rounded-circle'>";

													}

												echo "</div>
												<div class='col-10 ps-2'>";

													$clientsId = $row["clients_id"];

													$sql2 = "SELECT * FROM users WHERE id = $clientsId";
													$result2 = mysqli_query($conn, $sql2);

													while ($row2 = mysqli_fetch_assoc($result2)) {

														echo "<div class='text-dark'>" . $row2["name"] . "</div>";

													}

													if ($row["status"] == "unseen") {
														
														echo "<div class='text-muted fw-bold small mt-1'>" . $row["message"] . "</div>";

													} else {

														echo "<div class='text-muted small mt-1'>" . $row["message"] . "</div>";

													}

													echo "<div class='text-muted small mt-1'>" . date('M d | h:i A', strtotime($row["created_at"])) . "</div>
												</div>
											</div>
										</a>";

									}

								}

								?>

							</div>
							<div class="dropdown-menu-footer">
								<a href="#" class="text-muted">Show all messages</a>
							</div>
						</div>
					</li>
					<li class="nav-item dropdown">
						<a class="nav-icon dropdown-toggle d-inline-block d-sm-none" href="#" data-bs-toggle="dropdown">
							<i class="align-middle" data-feather="settings"></i>
						</a>

						<a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#" data-bs-toggle="dropdown">
							
							<?php

							$usersId = $_SESSION["id"];

							$sql = "SELECT * FROM users WHERE id = $usersId";
							$result = mysqli_query($conn, $sql);

							if (mysqli_num_rows($result) > 0) {

								while ($row = mysqli_fetch_assoc($result)) {

									echo "<img src='" . $baseUrl . "assets/uploads/cards/" . $row["card"] . "' class='avatar img-fluid rounded me-1' /> <span class='text-dark'>" . $row["name"] . "</span>";

								}

							}

							?>

						</a>
						<div class="dropdown-menu dropdown-menu-end">
							<a class="dropdown-item" href="<?= $baseUrl; ?>designer/profile"><i class="align-middle me-1" data-feather="user"></i> Profile</a>
							<div class="dropdown-divider"></div>
							<a class="dropdown-item" href="<?= $baseUrl; ?>assets/includes/sessions.inc.php?signOut">Log out</a>
						</div>
					</li>
				</ul>
			</div>
		</nav>

		<main class="content">
			<div class="container-fluid p-0">