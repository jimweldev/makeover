<?php 

$conn = mysqli_connect("localhost", "root", "", "makeover");

if (!$conn) {
	die("connection failed: " . mysqli_connect_errno());
	die("connection failed: " . mysqli_connect_error());
}

include "functions.inc.php";