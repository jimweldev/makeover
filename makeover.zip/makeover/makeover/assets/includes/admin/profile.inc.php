<?php

$baseUrl = "../../../";

include $baseUrl . "assets/includes/dbh.inc.php";

session_start();

if (isset($_POST["updateProfile"])) {

	$usersId = $_SESSION["id"];
	$email = mysqli_real_escape_string($conn, $_POST["email"]);
	$name = mysqli_real_escape_string($conn, $_POST["name"]);
	$bio = mysqli_real_escape_string($conn, $_POST["bio"]);
	$website = mysqli_real_escape_string($conn, $_POST["website"]);
	$facebook = mysqli_real_escape_string($conn, $_POST["facebook"]);
	$address = mysqli_real_escape_string($conn, $_POST["address"]);
	$contactNo = mysqli_real_escape_string($conn, $_POST["contactNo"]);
	$password = mysqli_real_escape_string($conn, $_POST["password"]);

	$sql = "SELECT * FROM users WHERE id = $usersId";
	$result = mysqli_query($conn, $sql);

	while ($row = mysqli_fetch_assoc($result)) {

		if (password_verify($password, $row["password"])) {
			
			if (empty($_FILES['image']['tmp_name'])) {

				$sql = "UPDATE users SET email = '$email', name = '$name', bio = '$bio', website = '$website', facebook = '$facebook', address = '$address', contact_no = '$contactNo' WHERE id = $usersId";
				mysqli_query($conn, $sql);

				$_SESSION["firstname"] = $firstname;

				header("Location: " . $baseUrl . "admin/profile/?success");
				exit();

			} else {

				$fileName = $_FILES['image']['name'];
				$fileTmpName = $_FILES['image']['tmp_name'];

				$fileExt = explode(".", $fileName);
				$fileExt = strtolower(end($fileExt));

				$fileName = uniqid("", true) . "." . $fileExt;

				$fileDestination =  $baseUrl . "assets/uploads/cards/" . $fileName;

				move_uploaded_file($fileTmpName, $fileDestination);

				$sql = "UPDATE users SET email = '$email', name = '$name', bio = '$bio', website = '$website', facebook = '$facebook', address = '$address', contact_no = '$contactNo', card = '$fileName' WHERE id = $usersId";
				mysqli_query($conn, $sql);

				$_SESSION["firstname"] = $firstname;

				header("Location: " . $baseUrl . "admin/profile/?success");
				exit();

			}

		} 

		header("Location: " . $baseUrl . "admin/profile/?error=Incorrect password");
		exit();

	}	

}

if (isset($_POST["updatePassword"])) {

	$usersId = $_SESSION["id"];
	$oldPassword = mysqli_real_escape_string($conn, $_POST["oldPassword"]);
	$newPassword = mysqli_real_escape_string($conn, $_POST["newPassword"]);
	$confirmPassword = mysqli_real_escape_string($conn, $_POST["confirmPassword"]);

	if ($newPassword != $confirmPassword) {
		
		header("Location: " . $baseUrl . "admin/profile/change-password?error=Passwords Mismatch");
		exit();

	}

	$sql = "SELECT * FROM users WHERE id = $usersId";
	$result = mysqli_query($conn, $sql);

	while ($row = mysqli_fetch_assoc($result)) {

		if (password_verify($oldPassword, $row["password"])) {

			$password = password_hash($newPassword, PASSWORD_DEFAULT);

			$sql = "UPDATE users SET password = '$password' WHERE id = $usersId";
			mysqli_query($conn, $sql);

			header("Location: " . $baseUrl . "admin/profile/change-password?success");
			exit();

		}

		header("Location: " . $baseUrl . "admin/profile/change-password?error=Incorrect password");
		exit();

	}

}