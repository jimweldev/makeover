<?php

$baseUrl = "../../../";

include $baseUrl . "assets/includes/dbh.inc.php";

session_start();

if (isset($_GET["activateUser"])) {

	$usersId = $_GET["id"];

	$sql = "UPDATE users SET status = 'active' WHERE id = '$usersId'";
	mysqli_query($conn, $sql);

	header("Location: " . $baseUrl . "admin/users?success");
	exit();

}

if (isset($_GET["deactivateUser"])) {

	$usersId = $_GET["id"];

	$sql = "UPDATE users SET status = 'inactive' WHERE id = '$usersId'";
	mysqli_query($conn, $sql);

	header("Location: " . $baseUrl . "admin/users?success");
	exit();

}