<?php

$baseUrl = "../../../";

include $baseUrl . "assets/includes/dbh.inc.php";

session_start();

if (isset($_POST["sendMessage"])) {

	$clientsId = mysqli_real_escape_string($conn, $_POST["clientsId"]);
	$designersId = mysqli_real_escape_string($conn, $_POST["designersId"]);
	$message = mysqli_real_escape_string($conn, $_POST["message"]);
	$today = date('Y-m-d H:i:s', time());

	$sql = "INSERT INTO messages (designers_id, clients_id, users_type, message, created_at, status) VALUES ($designersId, $clientsId, 'client', '$message', '$today', 'unseen')";

	if (mysqli_query($conn, $sql)) {

		header("Location: " . $baseUrl . "client/chat?id=" . $designersId);
		exit();

	}

	header("Location: " . $baseUrl . "client/chat?error=er");
	exit();

}

if (isset($_GET["viewMessage"])) {
	
	$clientsId = $_SESSION["id"];
	$designersId = mysqli_real_escape_string($conn, $_GET["id"]);

	$sql = "UPDATE messages SET status = 'seen' WHERE designers_id = $designersId AND clients_id = $clientsId AND users_type = 'designer'";
	mysqli_query($conn, $sql);

	header("Location: " . $baseUrl . "client/chat?id=" . $designersId);
	exit();

}