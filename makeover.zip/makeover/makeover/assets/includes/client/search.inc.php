<?php

$baseUrl = "../../../";

include $baseUrl . "assets/includes/dbh.inc.php";

if (isset($_POST["searchProducts"])) {
	
	$query = mysqli_real_escape_string($conn, $_POST["query"]);

	header("Location: " . $baseUrl . "client/products?q=" . $query);
	exit();	

}

if (isset($_POST["searchDesigners"])) {
	
	$query = mysqli_real_escape_string($conn, $_POST["query"]);

	header("Location: " . $baseUrl . "client/designers?q=" . $query);
	exit();	

}