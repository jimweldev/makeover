<?php

$baseUrl = "../../../";

include $baseUrl . "assets/includes/dbh.inc.php";

session_start();

if (isset($_GET["buyProduct"])) {

	$clientsId = $_SESSION["id"];
	$productsId = $_GET["id"];
	$today = date('Y-m-d H:i:s', time());

	$sql = "SELECT * FROM products WHERE id = $productsId";
	$result = mysqli_query($conn, $sql);

	if (mysqli_num_rows($result) > 0) {

		while ($row = mysqli_fetch_assoc($result)) {

			$designersId = $row["designers_id"];
			$totalPrice = ($row["price"] + $row["shipping_fee"]);

		}

	}

	$sql = "INSERT INTO orders (products_id, designers_id, clients_id, total_price, created_at) VALUES ($productsId, $designersId, $clientsId, $totalPrice, '$today')";

	if (mysqli_query($conn, $sql)) {

		$sql = "SELECT * FROM products WHERE id = $productsId";
		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) > 0) {

			while ($row = mysqli_fetch_assoc($result)) {

				$designersId = $row["designers_id"];
				$productsName = $row["name"];
				$stocks = $row["stocks"];

			}

		}

		$title = "Sold Product";
		$description = $productsName . " has been sold.";
		$today = date('Y-m-d H:i:s', time());

		$sql = "INSERT INTO notifications (users_id, title, description, created_at, status) VALUES ($designersId, '$title', '$description', '$today', 'unseen')";
		mysqli_query($conn, $sql);

		$stocks = $stocks - 1;

		$sql = "UPDATE products SET stocks = '$stocks' WHERE id = '$productsId'";
		mysqli_query($conn, $sql);

		header("Location: " . $baseUrl . "client/transactions?success");
		exit();

	}

}
