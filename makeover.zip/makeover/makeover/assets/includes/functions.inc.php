<?php

function value($get) {

	if (isset($_GET[$get])) {

		echo $_GET[$get];

	}

}

function page($page, $active) {

	if ($page == $active) {
		
		echo "active";

	}

}

function alert() {

	if (isset($_GET["success"])) {
		
		echo "<div class='alert alert-success alert-dismissible fade show' role='alert'>";
			echo "<i class='align-middle me-2' data-feather='check-circle'></i>";
			echo "<strong>Success!</strong>";
			echo "<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>";
		echo "</div>";

	} else if (isset($_GET["error"])) {

		echo "<div class='alert alert-danger alert-dismissible fade show' role='alert'>";
			echo "<i class='align-middle me-2' data-feather='alert-circle'></i>";
			echo "<strong>Error!</strong> " . $_GET["error"];
			echo "<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>";
		echo "</div>";

	} else if (isset($_GET["info"])) {

		echo "<div class='alert alert-info alert-dismissible fade show' role='alert'>";
			echo "<i class='align-middle me-2' data-feather='alert-circle'></i>";
			echo "<strong>Info!</strong> " . $_GET["info"];
			echo "<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>";
		echo "</div>";

	}

}

function allowedRole($baseUrl, $role) {

	if ($_SESSION["role"] != $role) {

		header("Location: " . $baseUrl);
		exit();
		
	}
}
