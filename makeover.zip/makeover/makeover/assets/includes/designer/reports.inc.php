<?php

$baseUrl = "../../../";

include $baseUrl . "assets/includes/dbh.inc.php";

session_start();

$sellersId = $_GET["seller"];
$month = $_GET["month"];
$year = $_GET["year"];

$first = date($year . "-" . $month . "-01");
$last = date($year . "-" . $month . "-t");

if (isset($_GET["table"])) {

	$sql = "SELECT * FROM orders WHERE designers_id = $sellersId AND created_at BETWEEN '$first' AND '$last'";
	$result = mysqli_query($conn, $sql);

	if (mysqli_num_rows($result) > 0) {

		while ($row = mysqli_fetch_assoc($result)) {

			echo "<tr>
						<td>" . (80000 + $row["id"]) . "</td>";

						$productsId = $row["products_id"];

						$sql2 = "SELECT * FROM products WHERE id = $productsId";
						$result2 = mysqli_query($conn, $sql2);

						while ($row2 = mysqli_fetch_assoc($result2)) {

							echo "<td>" . $row2["name"] . "</td>";

						}

						$clientsId = $row["clients_id"];

						$sql2 = "SELECT * FROM users WHERE id = $clientsId";
						$result2 = mysqli_query($conn, $sql2);

						while ($row2 = mysqli_fetch_assoc($result2)) {

							echo "<td>" . $row2["name"] . "</td>";

						}

						echo "<td>₱" . number_format($row["total_price"] - ($row["total_price"] / 100) * 5, 2) . "</td>
						<td>" . date('M d, Y', strtotime($row["created_at"])) . "</td>
						<td>
							<a class='btn btn-primary' href='./chat?id=" . $row["clients_id"] . "'>Send Message</a>
						</td>
					</tr>";

		}

	} else {
		echo "<tr>
			<td class='text-center' colspan='100%'>No data available</td>
		</tr>";
	}

}

if (isset($_GET["sales"])) {

	$sql = "SELECT COUNT(id) as count FROM orders WHERE designers_id = $sellersId AND created_at BETWEEN '$first' AND '$last'";
	$result = mysqli_query($conn, $sql);

	if (mysqli_num_rows($result) > 0) {

		while ($row = mysqli_fetch_assoc($result)) {

			echo $row["count"];

		}

	}

}

if (isset($_GET["earnings"])) {

	$sql = "SELECT * FROM orders WHERE designers_id = $sellersId AND created_at BETWEEN '$first' AND '$last'";
	$result = mysqli_query($conn, $sql);

	$total = 0;

	if (mysqli_num_rows($result) > 0) {

		while ($row = mysqli_fetch_assoc($result)) {

			$total += (($row["total_price"]) - (($row["total_price"] / 100) * 5));

		}

		echo "₱" . number_format($total, 2);

	} else {

		echo "₱0.00";

	}

}