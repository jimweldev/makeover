<?php

$baseUrl = "../../../";

include $baseUrl . "assets/includes/dbh.inc.php";

session_start();

if (isset($_GET["viewNotification"])) {

	$notificationsId = mysqli_real_escape_string($conn, $_GET["id"]);

	$sql = "UPDATE notifications SET status = 'seen' WHERE id = $notificationsId";
	mysqli_query($conn, $sql);

	header("Location: " . $baseUrl . "designer");
	exit();

}
