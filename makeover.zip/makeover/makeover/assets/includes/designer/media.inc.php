<?php

$baseUrl = "../../../";

include $baseUrl . "assets/includes/dbh.inc.php";

session_start();

if (isset($_POST["sendImage"])) {

	$clientsId = mysqli_real_escape_string($conn, $_POST["clientsId"]);
	$designersId = mysqli_real_escape_string($conn, $_POST["designersId"]);
	$today = date('Y-m-d H:i:s', time());

	$fileName = $_FILES['image']['name'];
	$fileTmpName = $_FILES['image']['tmp_name'];

	$fileExt = explode(".", $fileName);
	$fileExt = strtolower(end($fileExt));

	$fileName = uniqid("", true) . "." . $fileExt;

	$fileDestination =  $baseUrl . "assets/uploads/images/" . $fileName;

	move_uploaded_file($fileTmpName, $fileDestination);

	$sql = "INSERT INTO images (designers_id, clients_id, users_type, images, created_at, status) VALUES ($designersId, $clientsId, 'designer', '$fileName', '$today', 'unseen')";

	if (mysqli_query($conn, $sql)) {

		header("Location: " . $baseUrl . "designer/chat?id=" . $clientsId);
		exit();

	}

	header("Location: " . $baseUrl . "designer/chat?error=errr");
	exit();

}