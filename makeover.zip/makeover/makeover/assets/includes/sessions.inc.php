<?php

$baseUrl = "../../";

include $baseUrl . "assets/includes/dbh.inc.php";

if (isset($_POST["signUp"])) {

	$firstname = mysqli_real_escape_string($conn, $_POST["firstname"]);
	$lastname = mysqli_real_escape_string($conn, $_POST["lastname"]);
	$name = $firstname . " " . $lastname;
	$address = mysqli_real_escape_string($conn, $_POST["address"]);
	$contactNo = mysqli_real_escape_string($conn, $_POST["contactNo"]);
	$role = mysqli_real_escape_string($conn, $_POST["role"]);
	$email = mysqli_real_escape_string($conn, $_POST["email"]);
	$password = mysqli_real_escape_string($conn, $_POST["password"]);
	$confirmPassword = mysqli_real_escape_string($conn, $_POST["confirmPassword"]);
	$status = "inactive";

	if ($role == "client") {
		
		$status = "active";

	}

	if (!isset($_POST["termsAndConditions"])) {
		
		header("Location: " . $baseUrl . "sign-up?error=You must agree in all Terms and Conditions&firstname=" . $firstname . "&lastname=" . $lastname . "&address=" . $address . "&contactNo=" . $contactNo . "&email=" . $email);
		exit();

	}
	
	$sql = "SELECT * FROM users WHERE email = '$email'";
	$result = mysqli_query($conn, $sql);

	if (mysqli_num_rows($result) > 0) {

		header("Location: " . $baseUrl . "sign-up?error=Email is already taken&firstname=" . $firstname . "&lastname=" . $lastname . "&address=" . $address . "&contactNo=" . $contactNo . "&email=" . $email);
		exit();

	}

	if ($password != $confirmPassword) {
			
		header("Location: " . $baseUrl . "sign-up?error=Passwords mismatch&firstname=" . $firstname . "&lastname=" . $lastname . "&address=" . $address . "&contactNo=" . $contactNo . "&email=" . $email);
		exit();

	}

	$password = password_hash($password, PASSWORD_DEFAULT);

	$fileName = $_FILES['image']['name'];
	$fileTmpName = $_FILES['image']['tmp_name'];

	$fileExt = explode(".", $fileName);
	$fileExt = strtolower(end($fileExt));

	$fileName = uniqid("", true) . "." . $fileExt;

	$fileDestination =  $baseUrl . "assets/uploads/cards/" . $fileName;

	move_uploaded_file($fileTmpName, $fileDestination);

	$sql = "INSERT INTO users (name, address, contact_no, card, role, email, password, status, code) VALUES ('$name', '$address', '$contactNo', '$fileName', '$role', '$email', '$password', '$status', 'none')";

	if (mysqli_query($conn, $sql)) {

		if ($role == "designer") {
			
			header("Location: " . $baseUrl . "sign-in?info=Please wait for the confirmation of the admin.");
			exit();

		}
		
		session_start();
		session_regenerate_id();
		$_SESSION["id"] = mysqli_insert_id($conn);
		$_SESSION["name"] = $name;
		$_SESSION["role"] = $role;
		session_write_close();

		if ($_SESSION["role"] == "client") {
			
			header("Location: " . $baseUrl . "client");
			exit();

		} else if ($_SESSION["role"] == "designer") {

			header("Location: " . $baseUrl . "designer");
			exit();

		}

	}

	header("Location: " . $baseUrl . "sign-up?error=SQL error&firstname=" . $firstname . "&lastname=" . $lastname . "&address=" . $address . "&contactNo=" . $contactNo . "&email=" . $email);
	exit();

}

if (isset($_POST["signIn"])) {

	$email = mysqli_real_escape_string($conn, $_POST["email"]);
	$password = mysqli_real_escape_string($conn, $_POST["password"]);

	$sql = "SELECT * FROM users WHERE email = '$email'";
	$result = mysqli_query($conn, $sql);

	if (mysqli_num_rows($result) > 0) {

		while ($row = mysqli_fetch_assoc($result)) {

			if ($row["status"] == "inactive") {

				header("Location: " . $baseUrl . "sign-in?info=Please wait for the confirmation of the admin.");
				exit();

			}

			if (password_verify($password, $row["password"])) {
				
				session_start();
				session_regenerate_id();
				$_SESSION["id"] = $row["id"];
				$_SESSION["name"] = $row["name"];
				$_SESSION["role"] = $row["role"];
				session_write_close();

				if ($_SESSION["role"] == "client") {
			
					header("Location: " . $baseUrl . "client");
					exit();

				} else if ($_SESSION["role"] == "designer") {

					header("Location: " . $baseUrl . "designer");
					exit();

				} else if ($_SESSION["role"] == "admin") {

					header("Location: " . $baseUrl . "admin");
					exit();

				} else {

					session_start();
					session_destroy();

					header("Location: " . $baseUrl . "sign-in?error=Role error&email=" . $email);
					exit();

				}

			}

			header("Location: " . $baseUrl . "sign-in?error=Incorrect password&email=" . $email);
			exit();

		}

	}

	header("Location: " . $baseUrl . "sign-in?error=Email not found&email=" . $email);
	exit();

}

if (isset($_GET["signOut"])) {
	
	session_start();
	session_destroy();

	header("Location: " . $baseUrl);
	exit();

}

if (isset($_POST["recover"])) {
	
	$email = mysqli_real_escape_string($conn, $_POST["email"]);

	$sql = "SELECT * FROM users WHERE email = '$email'";
	$result = mysqli_query($conn, $sql);

	if (mysqli_num_rows($result) > 0) {

		if( !function_exists('random_bytes')) {
	    	function random_bytes($length = 6) {
		        $characters = '0123456789';
		        $characters_length = strlen($characters);
		        $output = '';
		        for ($i = 0; $i < $length; $i++)
		            $output .= $characters[rand(0, $characters_length - 1)];

		        return $output;
		    }
		}

		$code = bin2hex(random_bytes(3));

		$to = $email;
		$subject = "Password Recovery";
		$body = "http://localhost/makeover/recover?email=" . $email . "\nRecovery Code: " . $code;
		$headers = "From: shaomynameis21@gmail.com";

		if (mail($to, $subject, $body, $headers)) {

			$sql = "UPDATE users SET code = '$code' WHERE email = '$email'";
			mysqli_query($conn, $sql);
			
			header("Location: " . $baseUrl . "recover?email=" . $email);
			exit();

		} else {

			header("Location: " . $baseUrl . "recover?error=Failed to send code");
			exit();

		}

	}

	header("Location: " . $baseUrl . "recover?error=Email not found");
	exit();

}

if (isset($_POST["changePassword"])) {

	$email = mysqli_real_escape_string($conn, $_POST["email"]);
	$code = mysqli_real_escape_string($conn, $_POST["code"]);
	$password = mysqli_real_escape_string($conn, $_POST["password"]);
	$confirmPassword = mysqli_real_escape_string($conn, $_POST["confirmPassword"]);

	$sql = "SELECT * FROM users WHERE email = '$email'";
	$result = mysqli_query($conn, $sql);

	if ($password != $confirmPassword) {
			
		header("Location: " . $baseUrl . "recover?email=" . $email . "&error=Passwords mismatch");
		exit();

	}

	$password = password_hash($password, PASSWORD_DEFAULT);

	$sql = "UPDATE users SET password = '$password' WHERE email = '$email'";
	
	if (mysqli_query($conn, $sql)) {
		
		header("Location: " . $baseUrl . "sign-in?success");
		exit();

	}

	header("Location: " . $baseUrl . "recover?email=" . $email . "&error=SQL error");
	exit();

}