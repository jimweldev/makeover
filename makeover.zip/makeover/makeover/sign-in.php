<?php

$baseUrl = "./";

include $baseUrl . "assets/templates/home/header.inc.php";

?>

<div class="py-5 px-4">
	<div class="container">

		<?= alert(); ?>
		
		<div class="row">
			<form class="col-lg-4 offset-lg-4" action="<?= $baseUrl; ?>assets/includes/sessions.inc.php" method="POST">
				<h1 class="h3 text-center">Sign in</h1>

				<div class="mb-3">
					<label class="form-label">Email</label>
					<input class="form-control form-control-lg" type="email" placeholder="Enter your email" name="email" value="<?= value("email"); ?>" required>
				</div>

				<div class="mb-3">
					<label class="form-label">Password</label>
					<input class="form-control form-control-lg" type="password" placeholder="Enter your password" name="password" required>
					<a class="form-text text-muted" href="./recover">Forgot your password?</a>
				</div>

				<div class="text-center mt-3">
					<button class="btn btn-lg btn-primary" type="submit" name="signIn">Sign in</button>
				</div>
			</div>
		</form>

	</div>
</div>

<?php

include $baseUrl . "assets/templates/home/footer.inc.php";

?>